package com.blb.dao;


import com.blb.entity.Student;

import java.util.List;

public interface StudentDao {

    int insertStudent(Student student);

    List<Student> selectStudents();

}
